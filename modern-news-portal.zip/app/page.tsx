import { TopBar } from "@/components/top-bar"
import { Header } from "@/components/header"
import { BreakingNewsTicker } from "@/components/breaking-news-ticker"
import { HeroSection } from "@/components/hero-section"
import { EditorialSection } from "@/components/editorial-section"
import { InterviewCarousel } from "@/components/interview-carousel"
import { CultureSection } from "@/components/culture-section"
import { MultimediaSection } from "@/components/multimedia-section"
import { ClassifiedSection } from "@/components/classified-section"
import { Footer } from "@/components/footer"
import { Sidebar } from "@/components/sidebar"
import { mockNews, mostRead } from "@/lib/mockData"

export default function Home() {
  // Organize articles by type
  const featured = mockNews.filter((a) => a.featured).slice(0, 3)
  const editorial = mockNews.find((a) => a.type === "editorial")
  const interviews = mockNews.filter((a) => a.type === "interview")
  const cultureArticles = mockNews.filter((a) => a.category === "Cultura")

  return (
    <>
      <TopBar />
      <Header />
      <BreakingNewsTicker />

      <main className="min-h-screen">
        {/* Hero Section */}
        <HeroSection featured={featured} />

        {/* Main Content with Sidebar Layout */}
        <div className="px-4 md:px-6 py-12 bg-background">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Main Content */}
            <div className="lg:col-span-2 space-y-0">
              {/* Editorial Section */}
              {editorial && <EditorialSection editorial={editorial} />}

              {/* Interview Carousel */}
              {interviews.length > 0 && <InterviewCarousel interviews={interviews} />}

              {/* Culture Section */}
              {cultureArticles.length > 0 && <CultureSection cultureArticles={cultureArticles} />}

              {/* Multimedia Section */}
              <MultimediaSection />

              {/* Classified Section */}
              <ClassifiedSection />
            </div>

            {/* Right Column - Sidebar */}
            <div className="lg:col-span-1">
              <Sidebar mostRead={mostRead} />
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </>
  )
}
