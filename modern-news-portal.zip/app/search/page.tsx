import { TopBar } from "@/components/top-bar"
import { Header } from "@/components/header"
import { BreakingNewsTicker } from "@/components/breaking-news-ticker"
import { Footer } from "@/components/footer"
import { Breadcrumb } from "@/components/breadcrumb"
import { NewsCard } from "@/components/news-card"
import { Sidebar } from "@/components/sidebar"
import { mockNews, mostRead } from "@/lib/mockData"
import Link from "next/link"

interface SearchPageProps {
  searchParams: Promise<{
    q?: string
  }>
}

export async function generateMetadata(props: SearchPageProps) {
  const searchParams = await props.searchParams
  const query = searchParams.q || ""
  return {
    title: `Resultados para "${query}" - Portal de Notícias`,
    description: `${query ? `Resultados de busca para: ${query}` : "Página de busca"}`,
  }
}

export default async function SearchPage(props: SearchPageProps) {
  const searchParams = await props.searchParams
  const query = (searchParams.q || "").toLowerCase()

  const results = query
    ? mockNews.filter(
        (article) =>
          article.title.toLowerCase().includes(query) ||
          article.subtitle.toLowerCase().includes(query) ||
          article.content.toLowerCase().includes(query) ||
          article.tags.some((tag) => tag.toLowerCase().includes(query)),
      )
    : mockNews

  return (
    <>
      <TopBar />
      <Header />
      <BreakingNewsTicker />

      <main className="min-h-screen bg-background">
        <div className="px-4 md:px-6 py-12 bg-card border-b border-border">
          <div className="max-w-7xl mx-auto">
            <Breadcrumb items={[{ label: "Busca", href: "/search" }]} />

            <div className="mb-8">
              <h1 className="font-serif text-4xl md:text-5xl font-bold mb-3">
                {query ? `Resultados para: "${query}"` : "Busca de Notícias"}
              </h1>
              <p className="text-lg text-muted-foreground">
                {results.length} resultado{results.length !== 1 ? "s" : ""} encontrado{results.length !== 1 ? "s" : ""}
              </p>
            </div>
          </div>
        </div>

        <div className="px-4 md:px-6 py-12">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Search Results */}
            <div className="lg:col-span-2">
              {results.length > 0 ? (
                <div className="space-y-8">
                  {results.map((article) => (
                    <div key={article.id} className="pb-8 border-b border-border last:border-b-0">
                      <NewsCard article={article} variant="compact" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground text-lg mb-4">Nenhum resultado encontrado para "{query}"</p>
                  <Link href="/" className="text-primary hover:underline">
                    Voltar para a Home
                  </Link>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <Sidebar mostRead={mostRead} />
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </>
  )
}
