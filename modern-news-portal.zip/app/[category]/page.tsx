import { notFound } from "next/navigation"
import Link from "next/link"
import { TopBar } from "@/components/top-bar"
import { Header } from "@/components/header"
import { BreakingNewsTicker } from "@/components/breaking-news-ticker"
import { Footer } from "@/components/footer"
import { Breadcrumb } from "@/components/breadcrumb"
import { NewsCard } from "@/components/news-card"
import { Sidebar } from "@/components/sidebar"
import { mockNews, mostRead } from "@/lib/mockData"
import { getCategoryColor, getCategoryBgColor } from "@/lib/utils"

interface CategoryPageProps {
  params: Promise<{
    category: string
  }>
}

export async function generateMetadata(props: CategoryPageProps) {
  const params = await props.params
  const categoryName = params.category.charAt(0).toUpperCase() + params.category.slice(1)
  return {
    title: `${categoryName} - Portal de Notícias`,
    description: `Todas as notícias sobre ${categoryName}`,
  }
}

export async function generateStaticParams() {
  const categories = ["política", "economia", "esportes", "tecnologia", "cultura", "opinião", "podcast"]
  return categories.map((category) => ({
    category,
  }))
}

export default async function CategoryPage(props: CategoryPageProps) {
  const params = await props.params
  const categoryName = params.category.charAt(0).toUpperCase() + params.category.slice(1)

  const articles = mockNews.filter((article) => article.category.toLowerCase() === params.category.toLowerCase())

  if (articles.length === 0) {
    notFound()
  }

  return (
    <>
      <TopBar />
      <Header />
      <BreakingNewsTicker />

      <main className="min-h-screen bg-background">
        <div className="px-4 md:px-6 py-12 bg-card border-b border-border">
          <div className="max-w-7xl mx-auto">
            <Breadcrumb items={[{ label: categoryName, href: `/${params.category}` }]} />

            <div className={`${getCategoryBgColor(categoryName)} p-8 rounded-lg mb-8`}>
              <h1 className={`font-serif text-4xl md:text-5xl font-bold mb-3 ${getCategoryColor(categoryName)}`}>
                {categoryName}
              </h1>
              <p className="text-lg text-muted-foreground">
                {articles.length} artigo{articles.length !== 1 ? "s" : ""} nesta categoria
              </p>
            </div>
          </div>
        </div>

        <div className="px-4 md:px-6 py-12">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Articles Grid */}
            <div className="lg:col-span-2">
              {articles.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {articles.map((article) => (
                    <Link key={article.id} href={`/article/${article.slug}`}>
                      <NewsCard article={article} variant="grid" />
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground text-lg mb-4">
                    Nenhuma notícia disponível nesta categoria no momento.
                  </p>
                  <Link href="/" className="text-primary hover:underline">
                    Voltar para a Home
                  </Link>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <Sidebar mostRead={mostRead} />
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </>
  )
}
