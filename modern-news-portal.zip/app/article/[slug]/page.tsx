import { mockNews, mostRead } from "@/lib/mockData"
import { TopBar } from "@/components/top-bar"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { notFound } from "next/navigation"
import { ArticleBody } from "@/components/article-body"
import { CommentSection } from "@/components/comment-section"
import { Sidebar } from "@/components/sidebar"

interface ArticlePageProps {
  params: Promise<{ slug: string }>
}

export default async function ArticlePage({ params }: ArticlePageProps) {
  const { slug } = await params
  const article = mockNews.find((a) => a.slug === slug)

  if (!article) {
    notFound()
  }

  const relatedArticles = mockNews.filter((a) => a.category === article.category && a.id !== article.id).slice(0, 3)

  return (
    <>
      <TopBar />
      <Header />

      <main className="min-h-screen">
        <ArticleBody article={article} relatedArticles={relatedArticles} />

        {/* Related Articles Sidebar */}
        <div className="px-4 md:px-6 py-12 bg-background">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2" />
            <div className="lg:col-span-1">
              <Sidebar mostRead={mostRead} />
            </div>
          </div>
        </div>

        <CommentSection />
      </main>

      <Footer />
    </>
  )
}

export async function generateStaticParams() {
  return mockNews.map((article) => ({
    slug: article.slug,
  }))
}
