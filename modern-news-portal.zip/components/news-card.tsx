import Link from "next/link"
import type { NewsArticle } from "@/lib/types"
import { Eye, Clock } from "lucide-react"

interface NewsCardProps {
  article: NewsArticle
  variant?: "default" | "featured" | "compact" | "grid"
  imagePriority?: boolean
}

export function NewsCard({ article, variant = "default", imagePriority }: NewsCardProps) {
  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "2-digit",
    })
  }

  if (variant === "featured") {
    return (
      <Link href={`/article/${article.slug}`}>
        <article className="group cursor-pointer block">
          <div className="relative h-96 md:h-96 overflow-hidden rounded-lg mb-4">
            <img
              src={article.heroImage || "/placeholder.svg"}
              alt={article.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              loading={imagePriority ? "eager" : "lazy"}
            />
            <div className="absolute top-4 left-4">
              <span className="inline-block bg-accent text-accent-foreground px-3 py-1 text-xs font-bold rounded">
                {article.category}
              </span>
            </div>
          </div>
          <h2 className="font-serif text-3xl md:text-4xl font-bold mb-2 group-hover:text-primary transition-colors">
            {article.title}
          </h2>
          <p className="text-lg text-muted-foreground mb-4">{article.subtitle}</p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Eye className="w-4 h-4" />
              <span>{article.views?.toLocaleString("pt-BR")}</span>
            </div>
            <span>{formatDate(article.publishDate)}</span>
          </div>
        </article>
      </Link>
    )
  }

  if (variant === "compact") {
    return (
      <Link href={`/article/${article.slug}`}>
        <article className="group cursor-pointer hover:opacity-75 transition-opacity block">
          <div className="flex gap-4 items-start">
            <div className="flex-1 min-w-0">
              <h3 className="font-serif font-bold text-lg group-hover:text-primary transition-colors line-clamp-2 mb-2">
                {article.title}
              </h3>
              <p className="text-sm text-muted-foreground line-clamp-1 mb-2">{article.subtitle}</p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="line-clamp-1">{article.author.name}</span>
                <span>•</span>
                <span>{formatDate(article.publishDate)}</span>
              </div>
            </div>
            <img
              src={article.heroImage || "/placeholder.svg"}
              alt={article.title}
              className="w-24 h-24 object-cover rounded flex-shrink-0"
            />
          </div>
        </article>
      </Link>
    )
  }

  if (variant === "grid") {
    return (
      <Link href={`/article/${article.slug}`}>
        <article className="group cursor-pointer h-full block">
          <div className="relative h-48 overflow-hidden rounded-lg mb-4">
            <img
              src={article.heroImage || "/placeholder.svg"}
              alt={article.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
            <div className="absolute top-3 left-3">
              <span className="inline-block bg-accent text-accent-foreground px-2 py-1 text-xs font-bold rounded">
                {article.category}
              </span>
            </div>
          </div>
          <h3 className="font-serif text-lg font-bold mb-2 group-hover:text-primary transition-colors line-clamp-2">
            {article.title}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{article.subtitle}</p>
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="line-clamp-1">{article.author.name}</span>
            <div className="flex items-center gap-1 flex-shrink-0">
              <Clock className="w-3 h-3" />
              <span>{article.readingTime} min</span>
            </div>
          </div>
        </article>
      </Link>
    )
  }

  // Default variant
  return (
    <Link href={`/article/${article.slug}`}>
      <article className="group cursor-pointer block">
        <div className="relative h-48 overflow-hidden rounded-lg mb-4">
          <img
            src={article.heroImage || "/placeholder.svg"}
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute top-3 left-3">
            <span className="inline-block bg-accent text-accent-foreground px-2 py-1 text-xs font-bold rounded">
              {article.category}
            </span>
          </div>
        </div>
        <h3 className="font-serif text-xl font-bold mb-2 group-hover:text-primary transition-colors line-clamp-2">
          {article.title}
        </h3>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{article.subtitle}</p>
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>{article.author.name}</span>
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>{article.readingTime} min</span>
          </div>
        </div>
      </article>
    </Link>
  )
}
