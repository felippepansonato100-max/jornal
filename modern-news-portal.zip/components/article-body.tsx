"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Share2, Bookmark, MessageCircle, Heart } from "lucide-react"
import type { NewsArticle } from "@/lib/types"
import { formatDateBR, estimateReadingTime, getCategoryColor } from "@/lib/utils"

interface ArticleBodyProps {
  article: NewsArticle
  relatedArticles: NewsArticle[]
}

export function ArticleBody({ article, relatedArticles }: ArticleBodyProps) {
  const [readProgress, setReadProgress] = useState(0)
  const [isBookmarked, setIsBookmarked] = useState(false)
  const [likes, setLikes] = useState(Math.floor(Math.random() * 500) + 100)
  const [liked, setLiked] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY
      const docHeight = document.documentElement.scrollHeight - window.innerHeight
      const scrollPercent = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0
      setReadProgress(scrollPercent)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const shareOnSocial = (platform: string) => {
    const url = typeof window !== "undefined" ? window.location.href : ""
    const title = article.title
    const text = `${title} - ${url}`

    const shareUrls: Record<string, string> = {
      twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
      whatsapp: `https://wa.me/?text=${encodeURIComponent(text)}`,
    }

    if (shareUrls[platform]) {
      window.open(shareUrls[platform], "_blank")
    }
  }

  return (
    <>
      {/* Reading Progress Bar */}
      <div
        className="fixed top-0 left-0 h-1 bg-primary z-50 transition-all duration-300"
        style={{ width: `${readProgress}%` }}
      />

      {/* Article Header */}
      <article className="max-w-4xl mx-auto px-4 md:px-6 py-12">
        <div className="mb-6">
          <Link
            href={`/${article.category.toLowerCase()}`}
            className={`inline-block text-sm font-semibold ${getCategoryColor(article.category)} hover:opacity-75 transition-opacity`}
          >
            {article.category}
          </Link>
        </div>

        <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold mb-4 leading-tight">{article.title}</h1>

        <p className="text-xl md:text-2xl text-muted-foreground mb-6 font-serif leading-relaxed">{article.subtitle}</p>

        {/* Article Meta */}
        <div className="flex flex-wrap items-center justify-between gap-4 py-6 border-t border-b border-border">
          <div className="flex items-center gap-4">
            <img
              src={article.author.avatar || "/placeholder.svg"}
              alt={article.author.name}
              className="w-14 h-14 rounded-full object-cover"
            />
            <div>
              <p className="font-semibold">{article.author.name}</p>
              <p className="text-sm text-muted-foreground">{formatDateBR(article.publishDate)}</p>
            </div>
          </div>
          <div className="text-sm text-muted-foreground">
            <p>{article.readingTime || estimateReadingTime(article.content)} min de leitura</p>
          </div>
        </div>

        {/* Share Buttons */}
        <div className="flex items-center gap-2 my-6">
          <button
            onClick={() => shareOnSocial("twitter")}
            className="p-2 hover:bg-muted rounded-lg transition-colors"
            title="Compartilhar no Twitter"
          >
            <Share2 className="w-5 h-5" />
          </button>
          <button
            onClick={() => shareOnSocial("facebook")}
            className="p-2 hover:bg-muted rounded-lg transition-colors"
            title="Compartilhar no Facebook"
          >
            <Share2 className="w-5 h-5" />
          </button>
          <button
            onClick={() => shareOnSocial("whatsapp")}
            className="p-2 hover:bg-muted rounded-lg transition-colors"
            title="Compartilhar no WhatsApp"
          >
            <Share2 className="w-5 h-5" />
          </button>
          <button
            onClick={() => setIsBookmarked(!isBookmarked)}
            className="p-2 hover:bg-muted rounded-lg transition-colors ml-auto"
            title="Salvar artigo"
          >
            <Bookmark className={`w-5 h-5 ${isBookmarked ? "fill-current" : ""}`} />
          </button>
        </div>

        {/* Hero Image */}
        <div className="my-8 rounded-lg overflow-hidden">
          <img src={article.heroImage || "/placeholder.svg"} alt={article.title} className="w-full h-96 object-cover" />
        </div>

        {/* Article Content */}
        <div className="prose prose-lg max-w-none mb-12">
          {/* Drop Cap on first paragraph */}
          <style>{`
            .article-content p:first-of-type::first-letter {
              font-size: 3em;
              font-weight: bold;
              float: left;
              line-height: 1;
              padding-right: 8px;
              font-family: Georgia, serif;
            }
          `}</style>
          <div
            className="article-content"
            dangerouslySetInnerHTML={{
              __html: article.content,
            }}
          />
        </div>

        {/* Article Tags */}
        <div className="flex flex-wrap gap-2 py-6 border-t border-border mb-8">
          {article.tags.map((tag) => (
            <Link
              key={tag}
              href={`/?search=${encodeURIComponent(tag)}`}
              className="inline-block px-3 py-1 bg-muted text-foreground hover:bg-primary hover:text-primary-foreground rounded-full text-sm transition-colors"
            >
              #{tag}
            </Link>
          ))}
        </div>

        {/* Engagement Section */}
        <div className="flex items-center gap-4 py-6 border-t border-border mb-12">
          <button
            onClick={() => {
              setLiked(!liked)
              setLikes(liked ? likes - 1 : likes + 1)
            }}
            className="flex items-center gap-2 text-sm hover:text-primary transition-colors"
          >
            <Heart className={`w-5 h-5 ${liked ? "fill-red-500 text-red-500" : ""}`} />
            {likes}
          </button>
          <button className="flex items-center gap-2 text-sm hover:text-primary transition-colors">
            <MessageCircle className="w-5 h-5" />
            Comentários
          </button>
        </div>
      </article>
    </>
  )
}
