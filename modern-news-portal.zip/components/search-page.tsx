import type { NewsArticle } from "@/lib/types"
import { NewsCard } from "./news-card"
import { Search } from "lucide-react"

interface SearchPageProps {
  query: string
  results: NewsArticle[]
}

export function SearchPage({ query, results }: SearchPageProps) {
  return (
    <main className="min-h-screen px-4 md:px-6 py-12">
      <div className="max-w-7xl mx-auto">
        {/* Search Header */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-4">
            <Search className="w-6 h-6 text-accent" />
            <h1 className="font-serif text-3xl font-bold">Resultados da Busca</h1>
          </div>
          <p className="text-muted-foreground">
            {results.length} resultado{results.length !== 1 ? "s" : ""} encontrado{results.length !== 1 ? "s" : ""} para
            "{query}"
          </p>
        </div>

        {/* Results Grid */}
        {results.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {results.map((article) => (
              <NewsCard key={article.id} article={article} variant="default" />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <Search className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-lg text-muted-foreground mb-2">Nenhum resultado encontrado</p>
            <p className="text-sm text-muted-foreground">Tente outro termo de busca ou navegue pelas categorias</p>
          </div>
        )}
      </div>
    </main>
  )
}
