"use client"

import { useEffect, useState } from "react"
import { AlertCircle } from "lucide-react"

export function BreakingNewsTicker() {
  const [ticker, setTicker] = useState(0)

  const news = [
    "Prefeitura anuncia novo parque tecnológico",
    "Banco Central mantém taxa de juros em 13,75%",
    "Seleção Brasileira vence e vai à semifinal",
    "IA revoluciona produção em indústrias brasileiras",
    "Governo apresenta reforma tributária ambiciosa",
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setTicker((prev) => (prev + 1) % news.length)
    }, 6000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="bg-red-600 text-white py-2 px-4 overflow-hidden">
      <div className="max-w-7xl mx-auto flex items-center gap-4">
        <div className="flex items-center gap-2 whitespace-nowrap">
          <AlertCircle className="w-5 h-5 animate-pulse flex-shrink-0" />
          <span className="font-bold text-sm uppercase">Últimas Notícias</span>
        </div>
        <div className="relative flex-1 overflow-hidden h-6">
          {news.map((item, i) => (
            <div
              key={i}
              className={`absolute transition-opacity duration-500 text-sm ${
                i === ticker ? "opacity-100" : "opacity-0"
              }`}
            >
              {item}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
