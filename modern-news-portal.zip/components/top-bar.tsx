"use client"

import { useEffect, useState } from "react"
import { Cloud, DollarSign, Calendar } from "lucide-react"
import { ThemeToggle } from "./theme-toggle"

export function TopBar() {
  const [weather, setWeather] = useState("22°C")
  const [currentDate, setCurrentDate] = useState("")

  useEffect(() => {
    const date = new Date()
    const formatted = date.toLocaleDateString("pt-BR", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
    setCurrentDate(formatted.charAt(0).toUpperCase() + formatted.slice(1))
  }, [])

  return (
    <div className="w-full bg-gradient-to-r from-primary to-primary/80 text-primary-foreground py-2 px-4 text-sm">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            <span>{currentDate}</span>
          </div>
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4" />
            <span>Dólar: R$ 5,28</span>
          </div>
          <div className="flex items-center gap-2">
            <Cloud className="w-4 h-4" />
            <span>{weather} | Ensolarado</span>
          </div>
        </div>
        <ThemeToggle />
      </div>
    </div>
  )
}
