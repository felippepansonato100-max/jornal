import type { NewsArticle } from "@/lib/types"
import { NewsCard } from "./news-card"

interface CategoryPageProps {
  category: string
  articles: NewsArticle[]
}

export function CategoryPage({ category, articles }: CategoryPageProps) {
  const featuredArticle = articles[0]
  const otherArticles = articles.slice(1)

  return (
    <main className="min-h-screen">
      {/* Category Hero */}
      <div className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground py-12 px-4 md:px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="font-serif text-4xl md:text-5xl font-bold">{category}</h1>
          <p className="text-primary-foreground/80 mt-2">Últimas notícias sobre {category.toLowerCase()}</p>
        </div>
      </div>

      <div className="px-4 md:px-6 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Featured Article */}
          {featuredArticle && (
            <div className="mb-12">
              <NewsCard article={featuredArticle} variant="featured" />
            </div>
          )}

          {/* Grid of Articles */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {otherArticles.map((article) => (
              <NewsCard key={article.id} article={article} variant="default" />
            ))}
          </div>

          {/* No Articles Message */}
          {articles.length === 0 && (
            <div className="text-center py-12">
              <p className="text-lg text-muted-foreground">Nenhuma notícia encontrada nesta categoria.</p>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
