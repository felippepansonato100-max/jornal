import type { NewsArticle } from "@/lib/types"
import { NewsCard } from "./news-card"
import { Star, RotateCcw, Music } from "lucide-react"
import Link from "next/link"

interface CultureSectionProps {
  cultureArticles: NewsArticle[]
}

export function CultureSection({ cultureArticles }: CultureSectionProps) {
  const chronicles = cultureArticles.filter((a) => a.type === "chronicle")
  const reviews = cultureArticles.filter((a) => a.type === "review")

  return (
    <section className="py-12 px-4 md:px-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="font-serif text-3xl font-bold mb-12">Cultura</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Chronicles - Left Column */}
          <div>
            <h3 className="font-serif text-xl font-bold mb-6 flex items-center gap-2">
              <RotateCcw className="w-5 h-5 text-accent" />
              Crônicas
            </h3>
            <div className="space-y-6">
              {chronicles.map((article) => (
                <NewsCard key={article.id} article={article} variant="compact" />
              ))}
            </div>
          </div>

          {/* Reviews - Middle and Right */}
          <div className="md:col-span-2">
            <h3 className="font-serif text-xl font-bold mb-6 flex items-center gap-2">
              <Star className="w-5 h-5 text-accent" />
              Resenhas & Críticas
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {reviews.map((article) => (
                <Link key={article.id} href={`/article/${article.slug}`}>
                  <div className="bg-card border border-border rounded-lg p-6 hover:shadow-lg transition-shadow cursor-pointer block">
                    <div className="mb-4">
                      <span className="inline-block bg-accent text-accent-foreground px-2 py-1 text-xs font-bold rounded">
                        {article.category}
                      </span>
                    </div>
                    <h4 className="font-serif font-bold text-lg mb-2">{article.title}</h4>
                    <div className="flex gap-1 mb-3">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${i < 4 ? "fill-accent text-accent" : "text-muted-foreground"}`}
                        />
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-3 mb-4">{article.subtitle}</p>
                    <div className="text-sm font-medium text-accent">Ler Crítica →</div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* Cartoon Space Placeholder */}
        <div className="mt-12 bg-gradient-to-r from-muted to-muted/50 border border-border rounded-lg p-12 text-center">
          <Music className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
          <p className="text-muted-foreground">Espaço para Charge ou Conteúdo Visual Especial</p>
          <p className="text-xs text-muted-foreground mt-2">Publicidade ou Conteúdo Criativo</p>
        </div>
      </div>
    </section>
  )
}
