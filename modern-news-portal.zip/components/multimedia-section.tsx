import { Play, Headphones, Video } from "lucide-react"

export function MultimediaSection() {
  const multimedia = [
    {
      id: 1,
      type: "podcast",
      title: "Podcast: Os bastidores da política",
      description: "Especialistas debatem os movimentos políticos",
      image: "/placeholder.svg?key=xq5b2",
      duration: "52 min",
    },
    {
      id: 2,
      type: "video",
      title: "Especial: Documentário sobre IA",
      description: "Como a inteligência artificial está transformando",
      image: "/placeholder.svg?key=o003p",
      duration: "15 min",
    },
    {
      id: 3,
      type: "podcast",
      title: "Podcast: Economia Semanal",
      description: "Análise profunda do mercado financeiro",
      image: "/placeholder.svg?key=o9kof",
      duration: "38 min",
    },
  ]

  return (
    <section className="py-12 px-4 md:px-6 bg-card border-y border-border">
      <div className="max-w-7xl mx-auto">
        <h2 className="font-serif text-3xl font-bold mb-8 flex items-center gap-3">
          <Headphones className="w-8 h-8 text-accent" />
          Multimídia
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {multimedia.map((item) => (
            <div
              key={item.id}
              className="group cursor-pointer rounded-lg overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="relative h-48 overflow-hidden bg-muted">
                <img
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/50 transition-all flex items-center justify-center">
                  <Play className="w-12 h-12 text-white opacity-80 group-hover:opacity-100 transition-opacity" />
                </div>
                <div className="absolute top-3 right-3 bg-black/60 text-white px-2 py-1 rounded text-xs font-medium">
                  {item.type === "podcast" ? <Headphones className="w-3 h-3" /> : <Video className="w-3 h-3" />}
                </div>
              </div>
              <div className="bg-card border border-t-0 border-border p-4">
                <p className="text-xs uppercase text-accent font-bold mb-2">{item.type}</p>
                <h3 className="font-serif font-bold text-lg mb-2 line-clamp-2 group-hover:text-primary transition-colors">
                  {item.title}
                </h3>
                <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{item.description}</p>
                <p className="text-xs text-muted-foreground">{item.duration}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
