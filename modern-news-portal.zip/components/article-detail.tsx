"use client"

import type { NewsArticle } from "@/lib/types"
import { Eye, Calendar, Clock, Share2, Bookmark } from "lucide-react"
import { useState } from "react"
import Link from "next/link"

interface ArticleDetailProps {
  article: NewsArticle
  relatedArticles: NewsArticle[]
}

export function ArticleDetail({ article, relatedArticles }: ArticleDetailProps) {
  const [isSaved, setIsSaved] = useState(false)

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("pt-BR", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <>
      {/* Hero Image */}
      <div className="h-96 w-full overflow-hidden">
        <img src={article.heroImage || "/placeholder.svg"} alt={article.title} className="w-full h-full object-cover" />
      </div>

      <article className="max-w-4xl mx-auto px-4 md:px-6 py-12">
        {/* Header Section */}
        <header className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <span className="bg-accent text-accent-foreground px-3 py-1 text-sm font-bold rounded">
              {article.category}
            </span>
            <span className="text-xs text-muted-foreground uppercase font-bold">{article.type.replace("-", " ")}</span>
          </div>

          <h1 className="font-serif text-4xl md:text-5xl font-bold mb-4">{article.title}</h1>
          <p className="text-xl text-muted-foreground mb-6">{article.subtitle}</p>

          {/* Article Metadata */}
          <div className="flex flex-wrap items-center gap-6 pb-6 border-b border-border">
            {/* Author */}
            <div className="flex items-center gap-3">
              <img
                src={article.author.avatar || "/placeholder.svg"}
                alt={article.author.name}
                className="w-12 h-12 rounded-full object-cover"
              />
              <div>
                <p className="font-medium">{article.author.name}</p>
                <p className="text-xs text-muted-foreground">{article.author.bio}</p>
              </div>
            </div>

            {/* Date and Stats */}
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {formatDate(article.publishDate)}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {article.readingTime} min
              </span>
              <span className="flex items-center gap-1">
                <Eye className="w-4 h-4" />
                {article.views?.toLocaleString("pt-BR")}
              </span>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 ml-auto">
              <button className="p-2 hover:bg-muted rounded transition-colors">
                <Share2 className="w-5 h-5 text-muted-foreground hover:text-foreground" />
              </button>
              <button onClick={() => setIsSaved(!isSaved)} className="p-2 hover:bg-muted rounded transition-colors">
                <Bookmark className={`w-5 h-5 ${isSaved ? "fill-accent text-accent" : "text-muted-foreground"}`} />
              </button>
            </div>
          </div>
        </header>

        {/* Article Content */}
        <div className="prose prose-lg dark:prose-invert max-w-none mb-12">
          <div dangerouslySetInnerHTML={{ __html: article.content }} />
        </div>

        {/* Tags */}
        {article.tags.length > 0 && (
          <div className="py-6 border-t border-border">
            <p className="text-sm font-bold text-muted-foreground mb-3">TAGS</p>
            <div className="flex flex-wrap gap-2">
              {article.tags.map((tag) => (
                <Link key={tag} href={`/search?q=${encodeURIComponent(tag)}`}>
                  <span className="px-3 py-1 bg-muted text-foreground rounded text-sm hover:bg-accent hover:text-accent-foreground transition-colors inline-block cursor-pointer">
                    #{tag}
                  </span>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Related Articles */}
        {relatedArticles.length > 0 && (
          <section className="py-12 border-t border-border">
            <h2 className="font-serif text-2xl font-bold mb-8">Leitura Recomendada</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {relatedArticles.slice(0, 3).map((related) => (
                <Link key={related.id} href={`/article/${related.slug}`} className="group block">
                  <div className="relative h-40 overflow-hidden rounded-lg mb-3">
                    <img
                      src={related.heroImage || "/placeholder.svg"}
                      alt={related.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  </div>
                  <h3 className="font-serif font-bold group-hover:text-primary transition-colors line-clamp-2">
                    {related.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{related.subtitle}</p>
                </Link>
              ))}
            </div>
          </section>
        )}
      </article>
    </>
  )
}
