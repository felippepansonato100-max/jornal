import { ShoppingBag, Home, Briefcase } from "lucide-react"

export function ClassifiedSection() {
  const classifieds = [
    {
      id: 1,
      category: "Imóvel",
      icon: Home,
      title: "Apartamento em São Paulo",
      price: "R$ 450 mil",
      description: "3 quartos, 2 banheiros, varanda",
      date: "há 2 dias",
    },
    {
      id: 2,
      category: "Emprego",
      icon: Briefcase,
      title: "Desenvolvedor Full Stack",
      price: "R$ 8k - 12k",
      description: "Empresa tech em expansão busca senior",
      date: "ontem",
    },
    {
      id: 3,
      category: "Venda",
      icon: ShoppingBag,
      title: "iPhone 14 Pro",
      price: "R$ 3.200",
      description: "Seminovo, caixa e acessórios originais",
      date: "há 3 dias",
    },
    {
      id: 4,
      category: "Serviços",
      icon: Briefcase,
      title: "Consultoria em Marketing Digital",
      price: "Sob consulta",
      description: "Especialistas em estratégia e growth",
      date: "há 5 dias",
    },
  ]

  return (
    <section className="py-12 px-4 md:px-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="font-serif text-3xl font-bold mb-2">Classificados & Serviços</h2>
        <p className="text-muted-foreground mb-8">Oportunidades de negócios, imóveis e serviços</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {classifieds.map((item) => {
            const IconComponent = item.icon
            return (
              <div
                key={item.id}
                className="bg-card border border-border rounded-lg p-4 hover:border-accent hover:shadow-md transition-all cursor-pointer"
              >
                <div className="flex items-start gap-3 mb-3">
                  <div className="bg-accent/10 p-2 rounded">
                    <IconComponent className="w-5 h-5 text-accent" />
                  </div>
                  <span className="text-xs font-bold text-accent uppercase">{item.category}</span>
                </div>
                <h3 className="font-serif font-bold mb-2 line-clamp-2 hover:text-primary transition-colors">
                  {item.title}
                </h3>
                <p className="text-lg font-bold text-accent mb-2">{item.price}</p>
                <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{item.description}</p>
                <p className="text-xs text-muted-foreground">{item.date}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
