"use client"

import type React from "react"

import { useState } from "react"
import { User } from "lucide-react"

interface Comment {
  id: string
  author: string
  avatar: string
  date: string
  content: string
  likes: number
}

const mockComments: Comment[] = [
  {
    id: "1",
    author: "João Silva",
    avatar: "/journalist-male.jpg",
    date: "Há 2 horas",
    content:
      "Excelente análise sobre o tema. Concordo totalmente com as conclusões apresentadas. Este tipo de jornalismo investigativo é fundamental para a democracia.",
    likes: 45,
  },
  {
    id: "2",
    author: "Maria Santos",
    avatar: "/sports-journalist.jpg",
    date: "Há 1 hora",
    content:
      "Matéria muito bem estruturada com fontes confiáveis. Parabéns à redação pelo trabalho. Compartilhei com minha rede profissional.",
    likes: 32,
  },
  {
    id: "3",
    author: "Carlos Oliveira",
    avatar: "/journalist-interview.png",
    date: "Há 30 minutos",
    content:
      "Achei interessante a perspectiva apresentada. Gostaria de ver mais aprofundamento em alguns pontos específicos mencionados.",
    likes: 18,
  },
]

export function CommentSection() {
  const [comments, setComments] = useState<Comment[]>(mockComments)
  const [newComment, setNewComment] = useState("")
  const [submitting, setSubmitting] = useState(false)

  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newComment.trim()) return

    setSubmitting(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 500))

    const comment: Comment = {
      id: String(comments.length + 1),
      author: "Você",
      avatar: "/journalist-male.jpg",
      date: "Agora",
      content: newComment,
      likes: 0,
    }

    setComments([comment, ...comments])
    setNewComment("")
    setSubmitting(false)
  }

  return (
    <section className="max-w-4xl mx-auto px-4 md:px-6 py-12 border-t border-border">
      <h2 className="text-3xl font-serif font-bold mb-8">Comentários</h2>

      {/* New Comment Form */}
      <form onSubmit={handleSubmitComment} className="mb-12">
        <div className="flex gap-4 mb-4">
          <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
            <User className="w-6 h-6 text-muted-foreground" />
          </div>
          <textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Deixe seu comentário..."
            className="flex-1 px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary resize-none"
            rows={3}
            disabled={submitting}
          />
        </div>
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={!newComment.trim() || submitting}
            className="px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50"
          >
            {submitting ? "Enviando..." : "Enviar"}
          </button>
        </div>
      </form>

      {/* Comments List */}
      <div className="space-y-6">
        {comments.map((comment) => (
          <div key={comment.id} className="flex gap-4">
            <img
              src={comment.avatar || "/placeholder.svg"}
              alt={comment.author}
              className="w-12 h-12 rounded-full object-cover flex-shrink-0"
            />
            <div className="flex-1">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">{comment.author}</h3>
                <span className="text-sm text-muted-foreground">{comment.date}</span>
              </div>
              <p className="text-foreground mb-3 leading-relaxed">{comment.content}</p>
              <button className="text-sm text-muted-foreground hover:text-primary transition-colors">
                ❤ {comment.likes}
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
