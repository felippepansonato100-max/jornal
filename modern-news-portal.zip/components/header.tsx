"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Search, Menu, X } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { mockNews } from "@/lib/mockData"

export function Header() {
  const router = useRouter()
  const [searchOpen, setSearchOpen] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState(mockNews)
  const searchRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (searchQuery.trim()) {
      const filtered = mockNews.filter(
        (article) =>
          article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          article.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
          article.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
      )
      setSearchResults(filtered)
    } else {
      setSearchResults(mockNews)
    }
  }, [searchQuery])

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery)}`)
      setSearchOpen(false)
      setSearchQuery("")
    }
  }

  const categories = ["Política", "Economia", "Esportes", "Tecnologia", "Cultura", "Opinião", "Podcast"]

  return (
    <>
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="max-w-7xl mx-auto">
          {/* Logo and Main Nav */}
          <div className="flex items-center justify-between h-20 px-4 md:px-6">
            <Link
              href="/"
              className="font-serif text-2xl md:text-3xl font-bold text-primary hover:opacity-75 transition-opacity"
            >
              NOTÍCIAS<span className="text-accent">+</span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              {categories.map((cat) => (
                <Link
                  key={cat}
                  href={`/${cat.toLowerCase()}`}
                  className="text-sm font-medium hover:text-primary transition-colors"
                >
                  {cat}
                </Link>
              ))}
            </nav>

            {/* Search */}
            <div className="flex items-center gap-4">
              <div className="relative" ref={searchRef}>
                <button
                  onClick={() => setSearchOpen(!searchOpen)}
                  className="p-2 hover:bg-muted rounded-lg transition-colors"
                  title="Buscar"
                >
                  <Search className="w-5 h-5" />
                </button>

                {searchOpen && (
                  <div className="absolute right-0 top-full mt-2 w-80 bg-card border border-border rounded-lg shadow-lg p-4 z-50">
                    <form onSubmit={handleSearchSubmit} className="mb-2">
                      <input
                        type="text"
                        placeholder="Buscar notícias..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        autoFocus
                        className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                    </form>
                    <div className="max-h-96 overflow-y-auto">
                      {searchResults.length > 0 ? (
                        searchResults.map((article) => (
                          <Link
                            key={article.id}
                            href={`/article/${article.slug}`}
                            onClick={() => {
                              setSearchOpen(false)
                              setSearchQuery("")
                            }}
                          >
                            <div className="p-2 hover:bg-muted rounded text-sm line-clamp-2 mb-1 cursor-pointer">
                              {article.title}
                            </div>
                          </Link>
                        ))
                      ) : (
                        <p className="text-muted-foreground text-sm">Nenhum resultado encontrado</p>
                      )}
                    </div>
                  </div>
                )}
              </div>

              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 hover:bg-muted rounded-lg transition-colors"
                title="Menu"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <nav className="md:hidden border-t border-border py-4 px-4 flex flex-col gap-2">
              {categories.map((cat) => (
                <Link
                  key={cat}
                  href={`/${cat.toLowerCase()}`}
                  className="text-sm font-medium hover:text-primary transition-colors py-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {cat}
                </Link>
              ))}
            </nav>
          )}
        </div>
      </header>
    </>
  )
}
