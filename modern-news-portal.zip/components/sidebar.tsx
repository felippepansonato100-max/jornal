"use client"

import { useState } from "react"
import { Star, TrendingUp } from "lucide-react"
import type { NewsArticle } from "@/lib/types"

interface SidebarProps {
  mostRead: NewsArticle[]
}

export function Sidebar({ mostRead }: SidebarProps) {
  const [email, setEmail] = useState("")
  const [subscribed, setSubscribed] = useState(false)

  const handleSubscribe = () => {
    if (email) {
      setSubscribed(true)
      setTimeout(() => setSubscribed(false), 3000)
    }
  }

  const starRating = Array.from({ length: 5 }, (_, i) => (
    <Star key={i} className={`w-4 h-4 ${i < 4 ? "fill-accent text-accent" : "text-muted-foreground"}`} />
  ))

  return (
    <aside className="space-y-8">
      {/* Most Read */}
      <section className="bg-card border border-border rounded-lg p-6">
        <h3 className="font-serif text-xl font-bold mb-6 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-accent" />
          Mais Lidas
        </h3>
        <ol className="space-y-4">
          {mostRead.slice(0, 5).map((article, index) => (
            <li key={article.id} className="flex gap-3 pb-4 border-b border-border last:border-0">
              <span className="text-3xl font-serif font-bold text-accent/50 w-8">{index + 1}</span>
              <div className="flex-1 min-w-0">
                <a
                  href={`/article/${article.slug}`}
                  className="text-sm font-medium hover:text-primary transition-colors line-clamp-2"
                >
                  {article.title}
                </a>
              </div>
            </li>
          ))}
        </ol>
      </section>

      {/* Advertisement */}
      <section className="bg-gradient-to-br from-muted to-muted/50 border border-border rounded-lg p-6 h-80 flex items-center justify-center">
        <div className="text-center">
          <p className="text-sm text-muted-foreground">Espaço para Publicidade</p>
          <p className="text-xs text-muted-foreground mt-2">300x250px</p>
        </div>
      </section>

      {/* Newsletter */}
      <section className="bg-primary text-primary-foreground rounded-lg p-6">
        <h3 className="font-serif text-xl font-bold mb-2">Newsletter</h3>
        <p className="text-sm mb-4 opacity-90">Receba as principais notícias todos os dias na sua caixa de entrada.</p>
        <div className="space-y-2">
          <input
            type="email"
            placeholder="seu@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-3 py-2 rounded bg-primary-foreground text-primary text-sm focus:outline-none focus:ring-2 focus:ring-accent"
          />
          <button
            onClick={handleSubscribe}
            className="w-full bg-accent text-accent-foreground py-2 rounded font-medium hover:opacity-90 transition-opacity text-sm"
          >
            {subscribed ? "Inscrito!" : "Inscrever-se"}
          </button>
        </div>
      </section>

      {/* Events */}
      <section className="bg-card border border-border rounded-lg p-6">
        <h3 className="font-serif text-lg font-bold mb-4">Próximos Eventos</h3>
        <div className="space-y-3">
          {[
            { date: "20 Jan", title: "Conferência de Tecnologia" },
            { date: "25 Jan", title: "Debate Político" },
            { date: "30 Jan", title: "Festival de Cinema" },
          ].map((event, i) => (
            <div key={i} className="p-3 bg-muted rounded hover:bg-muted/75 transition-colors cursor-pointer">
              <p className="text-xs text-accent font-bold">{event.date}</p>
              <p className="text-sm font-medium">{event.title}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Culture Reviews Preview */}
      <section className="bg-card border border-border rounded-lg p-6">
        <h3 className="font-serif text-lg font-bold mb-4">Crítica do Mês</h3>
        <div className="space-y-4">
          <div>
            <p className="text-sm font-medium mb-2">Filme: "Uma Obra Prima"</p>
            <div className="flex gap-1 mb-2">{starRating}</div>
            <p className="text-xs text-muted-foreground">Crítica excelente pelo diretor.</p>
          </div>
        </div>
      </section>
    </aside>
  )
}
