"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, MessageCircle } from "lucide-react"
import type { NewsArticle } from "@/lib/types"
import Link from "next/link"

interface InterviewCarouselProps {
  interviews: NewsArticle[]
}

export function InterviewCarousel({ interviews }: InterviewCarouselProps) {
  const [activeIndex, setActiveIndex] = useState(0)

  const next = () => setActiveIndex((prev) => (prev + 1) % interviews.length)
  const prev = () => setActiveIndex((prev) => (prev - 1 + interviews.length) % interviews.length)

  const current = interviews[activeIndex]

  return (
    <section className="py-12 px-4 md:px-6 bg-card border-t border-border">
      <div className="max-w-7xl mx-auto">
        <h2 className="font-serif text-3xl font-bold mb-8 flex items-center gap-3">
          <MessageCircle className="w-8 h-8 text-accent" />
          Entrevistas
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          {/* Interview Image and Info */}
          <div className="relative">
            <div className="relative h-96 rounded-lg overflow-hidden mb-4">
              <img
                src={current.heroImage || "/placeholder.svg"}
                alt={current.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                <div className="text-white">
                  <p className="text-sm opacity-80 mb-2">Entrevista com</p>
                  <h3 className="font-serif text-2xl font-bold">{current.author.name}</h3>
                </div>
              </div>
            </div>

            {/* Navigation Buttons */}
            <div className="flex gap-3 justify-center">
              <button
                onClick={prev}
                className="bg-primary text-primary-foreground p-2 rounded-full hover:bg-primary/90 transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={next}
                className="bg-primary text-primary-foreground p-2 rounded-full hover:bg-primary/90 transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Interview Content */}
          <div>
            <h3 className="font-serif text-2xl font-bold mb-3">{current.title}</h3>
            <p className="text-muted-foreground mb-4">{current.subtitle}</p>

            {/* Interview Excerpt */}
            <div className="bg-muted rounded-lg p-4 mb-6 border-l-4 border-accent">
              <p className="text-sm italic">{current.content.replace(/<[^>]*>/g, "").substring(0, 200)}...</p>
            </div>

            <Link
              href={`/article/${current.slug}`}
              className="inline-block bg-accent text-accent-foreground px-6 py-3 rounded font-medium hover:opacity-90 transition-opacity"
            >
              Ler Entrevista Completa
            </Link>

            {/* Interview Indicators */}
            <div className="flex gap-2 mt-6">
              {interviews.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActiveIndex(i)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    i === activeIndex ? "bg-accent w-8" : "bg-muted-foreground"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
