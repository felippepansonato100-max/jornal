import type { NewsArticle } from "@/lib/types"
import { NewsCard } from "./news-card"

interface HeroSectionProps {
  featured: NewsArticle[]
}

export function HeroSection({ featured }: HeroSectionProps) {
  const mainArticle = featured[0]
  const sideArticles = featured.slice(1, 3)

  return (
    <section className="py-8 px-4 md:px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Main Featured Article - Larger */}
        {mainArticle && (
          <div className="md:col-span-2">
            <NewsCard article={mainArticle} variant="featured" imagePriority={true} />
          </div>
        )}

        {/* Side Featured Articles */}
        <div className="space-y-6">
          {sideArticles.map((article) => (
            <div key={article.id} className="h-full">
              <NewsCard article={article} variant="default" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
