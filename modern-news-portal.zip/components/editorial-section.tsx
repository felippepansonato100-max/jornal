import type { NewsArticle } from "@/lib/types"
import Link from "next/link"

interface EditorialSectionProps {
  editorial: NewsArticle
}

export function EditorialSection({ editorial }: EditorialSectionProps) {
  return (
    <section className="py-12 px-4 md:px-6 bg-gradient-to-r from-accent/10 to-accent/5">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          {/* Editorial Content */}
          <div className="md:col-span-2">
            <span className="inline-block text-accent font-bold text-sm uppercase tracking-wider mb-3">Editorial</span>
            <h2 className="font-serif text-3xl md:text-4xl font-bold mb-4">{editorial.title}</h2>
            <p className="text-lg text-muted-foreground mb-6">{editorial.subtitle}</p>
            <Link
              href={`/article/${editorial.slug}`}
              className="inline-block bg-primary text-primary-foreground px-6 py-3 rounded font-medium hover:bg-primary/90 transition-colors"
            >
              Ler Mais
            </Link>
          </div>

          {/* Editor Image */}
          <div className="flex flex-col items-center">
            <img
              src={editorial.author.avatar || "/placeholder.svg"}
              alt={editorial.author.name}
              className="w-32 h-32 rounded-full object-cover mb-4 border-4 border-accent"
            />
            <h3 className="font-serif font-bold text-lg">{editorial.author.name}</h3>
            <p className="text-sm text-muted-foreground text-center">{editorial.author.bio}</p>
          </div>
        </div>
      </div>
    </section>
  )
}
