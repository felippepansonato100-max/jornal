import type { DefaultSession } from "next-auth"

declare module "next-auth" {
  interface User {
    role: "GUEST" | "SUBSCRIBER" | "ADMIN"
  }

  interface Session {
    user: {
      role: "GUEST" | "SUBSCRIBER" | "ADMIN"
    } & DefaultSession["user"]
  }
}

export interface Author {
  name: string
  avatar: string
  bio?: string
}

export interface NewsArticle {
  id: string
  slug: string
  title: string
  subtitle: string
  content: string
  author: Author
  publishDate: Date
  category: "Política" | "Economia" | "Esportes" | "Tecnologia" | "Cultura" | "Opinião" | "Podcast"
  tags: string[]
  heroImage: string
  type: "breaking-news" | "editorial" | "report" | "interview" | "chronicle" | "review"
  featured?: boolean
  readingTime?: number
  views?: number
}

export interface Review {
  title: string
  rating: number
  reviewer: Author
}

export interface BlogPost {
  id: string
  title: string
  subtitle: string
  slug: string
  content: string
  category: string
  author: string
  heroImage: string
  status: "published" | "draft"
  createdAt: Date
  updatedAt: Date
}
