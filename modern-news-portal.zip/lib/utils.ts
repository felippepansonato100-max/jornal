import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function getCategoryColor(category: string): string {
  const colors: Record<string, string> = {
    Política: "text-red-700 dark:text-red-400",
    Economia: "text-blue-700 dark:text-blue-400",
    Esportes: "text-green-600 dark:text-green-400",
    Tecnologia: "text-purple-700 dark:text-purple-400",
    Cultura: "text-pink-600 dark:text-pink-400",
    Opinião: "text-amber-700 dark:text-amber-400",
    Podcast: "text-indigo-700 dark:text-indigo-400",
  }
  return colors[category] || "text-gray-700 dark:text-gray-400"
}

export function getCategoryBgColor(category: string): string {
  const colors: Record<string, string> = {
    Política: "bg-red-100 dark:bg-red-950",
    Economia: "bg-blue-100 dark:bg-blue-950",
    Esportes: "bg-green-100 dark:bg-green-950",
    Tecnologia: "bg-purple-100 dark:bg-purple-950",
    Cultura: "bg-pink-100 dark:bg-pink-950",
    Opinião: "bg-amber-100 dark:bg-amber-950",
    Podcast: "bg-indigo-100 dark:bg-indigo-950",
  }
  return colors[category] || "bg-gray-100 dark:bg-gray-900"
}

export function estimateReadingTime(content: string): number {
  const wordsPerMinute = 200
  const wordCount = content.trim().split(/\s+/).length
  return Math.ceil(wordCount / wordsPerMinute)
}

export function getSlugFromTitle(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^\w\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
}

export function formatDateBR(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date
  return d.toLocaleDateString("pt-BR", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })
}

export function formatDateBRShort(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date
  return d.toLocaleDateString("pt-BR", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  })
}
