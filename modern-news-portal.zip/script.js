// Gazeta do Observador - Portal de Notícias
// Script interativo

// Update current date
function updateCurrentDate() {
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" }
  const today = new Date()
  const formattedDate = today.toLocaleDateString("pt-BR", options)
  const capitalizedDate = formattedDate.charAt(0).toUpperCase() + formattedDate.slice(1)

  const dateElement = document.getElementById("current-date")
  if (dateElement) {
    dateElement.textContent = capitalizedDate
  }
}

// Smooth scroll for navigation
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    const href = this.getAttribute("href")
    if (href !== "#") {
      e.preventDefault()
      const target = document.querySelector(href)
      if (target) {
        target.scrollIntoView({ behavior: "smooth" })
      }
    }
  })
})

// Newsletter form submission
const newsletterForm = document.querySelector(".newsletter-form")
if (newsletterForm) {
  newsletterForm.addEventListener("submit", function (e) {
    e.preventDefault()
    const emailInput = this.querySelector('input[type="email"]')
    if (emailInput.value) {
      alert(`Email "${emailInput.value}" inscrito com sucesso! Verifique sua caixa de entrada.`)
      emailInput.value = ""
    }
  })
}

// Search functionality
const searchBox = document.querySelector(".search-box")
if (searchBox) {
  const searchButton = searchBox.querySelector("button")
  const searchInput = searchBox.querySelector("input")

  searchButton.addEventListener("click", () => {
    const query = searchInput.value.trim()
    if (query) {
      alert(`Pesquisando por: "${query}"\n\nFuncionalidade de busca em desenvolvimento.`)
      searchInput.value = ""
    }
  })

  searchInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      searchButton.click()
    }
  })
}

// Add click handlers to news cards
document.querySelectorAll(".news-card").forEach((card) => {
  card.addEventListener("click", function () {
    const title = this.querySelector(".news-title").textContent
    console.log(`Abrindo: ${title}`)
    // In a real app, this would navigate to the full article
  })
})

// Initialize
document.addEventListener("DOMContentLoaded", () => {
  updateCurrentDate()

  // Set active nav link based on scroll position
  window.addEventListener("scroll", () => {
    const sections = document.querySelectorAll("section")
    const navLinks = document.querySelectorAll(".nav-link")

    let current = ""
    sections.forEach((section) => {
      const sectionTop = section.offsetTop
      if (scrollY >= sectionTop - 200) {
        current = section.getAttribute("id")
      }
    })

    navLinks.forEach((link) => {
      link.classList.remove("active")
      if (link.getAttribute("href").slice(1) === current) {
        link.classList.add("active")
      }
    })
  })
})

console.log("✅ Gazeta do Observador - Portal carregado com sucesso!")
